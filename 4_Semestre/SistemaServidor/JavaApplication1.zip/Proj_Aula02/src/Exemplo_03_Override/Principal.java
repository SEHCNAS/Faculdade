/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exemplo_03_Override;

/**
 *
 * @author autologon
 */
public class Principal {
       
    //psvm + tab - gera o metodo main
    public static void main(String[] args) {
        Aluno obj_Aluno = new Aluno("Gabriel Sanches", 24, "a1a1a1");
        
        Aluno obj_Aluno2 = new Aluno("Aluno 2", 2, "a2a2a2");
        
        System.out.println(obj_Aluno.toString());
         System.out.println(obj_Aluno2.toString());
        
    }
    
}
