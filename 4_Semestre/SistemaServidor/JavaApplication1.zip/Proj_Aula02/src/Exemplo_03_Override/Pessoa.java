/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exemplo_03_Override;

/**
 *
 * @author autologon
 */ 
public class Pessoa {   
    //Atributos
    private String Nome;
    private int Idade;
    
    //Metodo construtor tem o mesmo nome da classe
    //Metod sem retorno
    //Caso não seja criado o java cria um vazio
    //
    //
    public Pessoa(String Nome, int Idade) {
        this.setNome(Nome);
        this.setIdade(Idade);
    }
    
    
    
    public String getNome() {
        return Nome;
    }

 
    public int getIdade() {
        return Idade;
    }

    public void setNome(String Nome) {
        if(Nome.isBlank()){
            System.out.println("O nome não pode ser vazio!");
        }
        else{
        this.Nome = Nome;}
    }

    public void setIdade(int Idade) {
        if(Idade < 0 || Idade > 120){
            System.out.println("Idade invalida!");
        }else{
        this.Idade = Idade;
        }
    }   
    
        @Override
    public String toString(){
        return "Nome: " + this.getNome() + "\nIdade: " + this.getIdade();
    }
}
