/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exemplo_03_Override;
/**
 *
 * @author autologon
 */
public class Aluno extends Pessoa{
    private String RGM;

    public Aluno(String Nome, int Idade, String RGM) {
        super(Nome, Idade);
        this.setRGM(RGM);
    }

    public String getRGM() {
        return RGM;
    }

    public void setRGM(String RGM) {
        this.RGM = RGM;
    }
    
    //Sobreescreve uma função ja existente
    @Override
    public String toString(){
        return super.toString() + "\nRGM: " + this.RGM;
    }
    
    
    
    
}
