/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exemplo_01_ExemploEncapsulamento;

/**
 *
 * @author autologon
 */
public class Principal {
       
    //psvm + tab - gera o metodo main
    public static void main(String[] args) {
        Pessoa obj_pessoa = new Pessoa();
        
        obj_pessoa.setIdade(24);
        obj_pessoa.setNome("Gabriel Sanches");
        
        //sout + tab para gerar uma linha de println
        System.out.println(obj_pessoa.getNome());
        System.out.println(obj_pessoa.getIdade());
        

    }
    
}
