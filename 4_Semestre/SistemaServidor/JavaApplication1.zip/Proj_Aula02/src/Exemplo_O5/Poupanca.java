/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exemplo_O5;

/**
 *
 * @author autologon
 */
public class Poupanca extends Conta{
    private int Aniversario;

    public Poupanca(String Banco, int Conta, int Agencia, int Aniversario) {
        super(Banco, Conta, Agencia);
        this.setAniversario(Aniversario);
    }

    @Override
    public void saque() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public int getAniversario() {
        return Aniversario;
    }

    public void setAniversario(int Aniversario) {
        this.Aniversario = Aniversario;
    }
    
    
}
