/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exemplo_O5;

import Exemplo_04_ClasseAbstract.*;

/**
 *
 * @author autologon
 */
public class Principal {
       
    //psvm + tab - gera o metodo main
    public static void main(String[] args) {
        
        Corrente obj_Corrente = new Corrente("Itau", 2, 3, 1000);
        
        Poupanca obj_Poupanca = new Poupanca("Bradesco", 2, 3, 1);
        
        obj_Corrente.Depositar(299);
        
        System.out.println("Saldo cc: " + obj_Corrente.getSaldo());
        
        obj_Poupanca.Depositar(333);
        
        System.out.println("Saldo pp: " + obj_Poupanca.getSaldo());
    }
    
}
