/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exemplo_O5;

/**
 *
 * @author autologon
 */
public class Corrente extends Conta{
    private double limite;

    public Corrente(String Banco, int Conta, int Agencia, double limite) {
        super(Banco, Conta, Agencia);
        this.setLimite(limite);
    }

    @Override
    public void saque() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public double getLimite() {
        return limite;
    }

    public void setLimite(double limite) {
        this.limite = limite;
    }
    
    
    
}
