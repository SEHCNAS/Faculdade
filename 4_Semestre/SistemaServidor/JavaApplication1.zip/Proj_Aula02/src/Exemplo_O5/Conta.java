/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exemplo_O5;

/**
 *
 * @author autologon
 */
public abstract class Conta {
    private double saldo;
    private String Banco;
    private int Conta;
    private int Agencia;
    
    public Conta(String Banco, int Conta, int Agencia){
        this.setBanco(Banco);
        this.setAgencia(Agencia);
        this.setConta(Conta);
        this.setSaldo(0);
    }
    
    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public String getBanco() {
        return Banco;
    }

    public void setBanco(String Banco) {
        
        if(Banco.length() >= 3){
        this.Banco = Banco;
        }
        else{
            System.out.println("Nome do banco invalido!");
        }
    }

    public int getConta() {
        return Conta;
    }

    public void setConta(int Conta) {
        if (Conta > 0){
        this.Conta = Conta;}
        else{
            System.out.println("Numero da conta invalida!");
        }
    }

    public int getAgencia() {
        return Agencia;
    }

    public void setAgencia(int Agencia) {
        if(Agencia > 0){
        this.Agencia = Agencia;}
        else{
            System.out.println("Numero de agencia invalida!");
        }
    }
   
    public void Depositar(double valor){
        if (valor > 0){
        this.saldo += valor;
        }
        else
        {
            System.out.println("O valor precisa ser positivo!");
        }
    };
    
    public abstract void saque();
}
