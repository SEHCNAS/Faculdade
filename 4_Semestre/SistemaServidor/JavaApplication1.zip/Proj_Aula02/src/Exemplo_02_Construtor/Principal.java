/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exemplo_02_Construtor;

/**
 *
 * @author autologon
 */
public class Principal {
       
    //psvm + tab - gera o metodo main
    public static void main(String[] args) {
        Pessoa obj_pessoa = new Pessoa("Gabriel Sanches", 24);
        
        System.out.println(obj_pessoa.getNome());
        System.out.println(obj_pessoa.getIdade());
        
    }
    
}
