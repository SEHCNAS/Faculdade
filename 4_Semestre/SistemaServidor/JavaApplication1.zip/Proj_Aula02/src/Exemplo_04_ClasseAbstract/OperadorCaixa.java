/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exemplo_04_ClasseAbstract;

/**
 *
 * @author autologon
 */
public class OperadorCaixa extends Pessoa{
    private double bonus;
    
    public OperadorCaixa(String Nome, int Idade, int salario, double bonus){
            super(Nome, Idade, salario);
            this.bonus = bonus;
    }
    
    
    public double getBonus(){
     return this.bonus;   
    }
    
    public void setBonus(Double Bonus){
    this.bonus = Bonus;
    }
    
    /**
     *
     */
    @Override
    public void CalculaSalario(){
        System.out.println("O salario total é:" + (this.getSalario() + this.bonus) );
    }
    
}
