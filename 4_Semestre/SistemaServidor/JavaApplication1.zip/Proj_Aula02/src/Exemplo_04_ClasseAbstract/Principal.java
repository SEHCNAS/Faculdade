/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exemplo_04_ClasseAbstract;

/**
 *
 * @author autologon
 */
public class Principal {
       
    //psvm + tab - gera o metodo main
    public static void main(String[] args) {
        
        Vendedor obj_Vendedor = new Vendedor("Joao", 29, 1000, 100);
        obj_Vendedor.CalculaSalario();
        
        OperadorCaixa obj_OperadorCaixa = new OperadorCaixa("Albert", 23, 1000, 200);
        obj_OperadorCaixa.CalculaSalario();
    }
    
}
