/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exemplo_04_ClasseAbstract;

/**
 *
 * @author autologon
 */
public class Vendedor extends Pessoa{
    
    private double comissao;
    
    public Vendedor(String Nome, int Idade, double salario, double comissao) {
        super(Nome, Idade, salario);
        this.setComissao(comissao);
    }
    
    public double getComissao() {
        return comissao;
    }

    public void setComissao(double comissao) {
        this.comissao = comissao;
    }
    
    @Override
    public void CalculaSalario(){
        System.out.println("O salario total é:" + (this.getSalario() + this.comissao) );
    }
    
}
