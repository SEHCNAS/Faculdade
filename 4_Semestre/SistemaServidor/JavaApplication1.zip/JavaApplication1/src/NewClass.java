
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author autologon
 */
import java.util.Scanner;

public class NewClass {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        System.out.println("Digite o nome: ");
        String nome = entrada.nextLine();
        
        System.out.println("Digite a idade: ");
        int idade = entrada.nextInt();
        
        System.out.print("Seu nome é: " + nome + "\n E sua idade é: " + idade
        + "\n");
    }
}
