/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Atv_4;

/**
 *
 * @author autologon
 */
public class Pessoa {
    protected String NomeCompleto;
    protected int Idade;

    public Pessoa() {
    }
    
    public Pessoa(String NomeCompleto, int Idade) {
        this.NomeCompleto = NomeCompleto;
        this.Idade = Idade;
    }
    

    public String getNomeCompleto() {
        return NomeCompleto;
    }

    public void setNomeCompleto(String NomeCompleto) {
        if(NomeCompleto.length() >= 2){
        this.NomeCompleto = NomeCompleto;
        }else{
            System.out.println("Nome invalido");};
        
    }

    public int getIdade() {
        return Idade;
    }

    public void setIdade(int Idade) {
        if(Idade > 0 && Idade < 120){
        this.Idade = Idade;
        }else{
            System.out.println("Idade invalida!");
        }
    }
}
