/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Atv_4;

/**
 *
 * @author autologon
 */
public class Produto implements Imprimir, Seguranca{



    private String Descricao;
    private int quantidade;

    public Produto(String d, int q){
        this.setDescricao(d);
        this.setQuantidade(q);
    }
    
    public String getDescricao() {
        return Descricao;
    }

    public void setDescricao(String Descricao) {
        if(Descricao.length() >= 2){
        this.Descricao = Descricao;
        }else{
            System.out.println("Descrição deve ter mais de 2 caracteres");
        }
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        if(Descricao.length() >= 0){
        this.quantidade = quantidade;
        }else{
            System.out.println("Quantidade invalida");
            }
    }
    
    @Override
    public String FormatoString() {
        String Retorno;
        Retorno = "Descrição: " + this.Descricao + "\nQuantidade: " + this.quantidade;
        return Retorno;
        
    }

    @Override
    public void FormatoSystemOut() {
        System.out.println("Descrição: " + this.Descricao + "\nQuantidade: " + this.quantidade);
      
    }    
    
    @Override
    public boolean validar() {
        boolean status;
        if(this.quantidade < 10){
            System.out.println("Quantidade invalida");
            status = false;
        }else{
            System.out.println("Quantidade valida");
            status = true;
        }
        return status;
    }
}
