/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Atv_4;

/**
 *
 * @author autologon
 */
public class Usuario extends Pessoa implements Imprimir, Seguranca{
    private String NomeUsuario;
    private String senha;

    public Usuario() {
       
    }
    
    public Usuario(String NomeUsuario, String senha) {
        this.NomeUsuario = NomeUsuario;
        this.senha = senha;
    }

    public String getNomeUsuario() {
        return NomeUsuario;
    }

    public void setNomeUsuario(String NomeUsuario) {
        this.NomeUsuario = NomeUsuario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    @Override
    public String FormatoString() {
        String resp;
        resp = "Nome: " + this.NomeCompleto + nlin +
                "idade: " + this.Idade + nlin +
                "Usuario: " + this.NomeUsuario + nlin + 
                "Senha: " + this.senha;
        return resp;
    }

    @Override
    public void FormatoSystemOut() {
        System.out.println("Nome: " + this.NomeCompleto + nlin +
                "idade: " + this.Idade + nlin +
                "Usuario: " + this.NomeUsuario + nlin + 
                "Senha: " + this.senha);
    }

    @Override
    public boolean validar() {
        if(this.senha.equals("") || this.NomeUsuario.endsWith("")){
            System.out.println("Senha ou nome de usuario invalido");
            return false;
        }
        return true;
    }
    
    
    
}
